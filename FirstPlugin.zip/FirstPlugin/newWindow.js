function addListeners() {
	$("#yourFileTop").on("change", function (e) {
		console.log(this.value);
		setPosition("#yourFileContainer", "top", this.value);
	});
}

function setPosition(selector, attr, value) {
	$(selector).css(attr, value);
}

addListeners();