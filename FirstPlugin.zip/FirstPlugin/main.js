document.addEventListener('DOMContentLoaded', function() {
    var createProperties = {
        url: "newWindow.html"
    };
    chrome.tabs.create(createProperties);
});
